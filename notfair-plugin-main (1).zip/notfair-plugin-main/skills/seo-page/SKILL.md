---
name: seo-page
argument-hint: "<URL of the page to analyze, e.g. https://example.com/blog/my-post>"
description: >
  Single-page SEO audit: content quality under Google's E-E-A-T framework and
  Helpful Content guidelines, on-page factors, search intent, technical signals and
  readability. Pulls GSC data for the page, crawls the live HTML, checks metadata,
  schema, internal linking and depth, and produces a scored report with fixes. Use
  whenever the user wants to analyze a specific page or URL, not the whole site.
  Trigger on: "analyze this page", "audit this URL", "how is this page doing",
  "evaluate my blog post", "check this landing page", "page SEO", "content quality
  check", "is this page good enough", "review this page's SEO", "what's wrong with
  this page", "how can I improve this page", "page analysis", "single page audit",
  "content audit for [URL]", or any request naming a specific URL/page for SEO
  evaluation. If the user provides a specific URL (not just a domain), this is
  likely the right skill; use /seo-analysis for full-site audits instead.
---

# Canonical NotFair workflow

Read [`../../seo/seo-page/WORKFLOW.md`](../../seo/seo-page/WORKFLOW.md) completely, then follow it as the active workflow. Resolve every relative reference from that file against `../../seo/seo-page/`.
